import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Mail, 
  Key, 
  ArrowRight, 
  UserRound, 
  Users, 
  Eye, 
  EyeOff, 
  Award, 
  CheckCircle2, 
  AlertCircle,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { useBjj } from '../context/BjjContext';
import { BeltBadge } from '../components/ui/BeltBadge';

export const Login: React.FC = () => {
  const { allUsers, loginWithEmailAndPassword, loginAsUser, academySettings } = useBjj();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'admin' | 'professor' | 'aluno'>('admin');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email.trim()) {
      setErrorMessage('Por favor, informe seu endereço de e-mail.');
      return;
    }

    const result = loginWithEmailAndPassword(email, password);
    if (!result.success) {
      setErrorMessage(result.message);
    }
  };

  const handleQuickLogin = (userId: string, userEmail: string, userPass?: string) => {
    setEmail(userEmail);
    if (userPass) {
      setPassword(userPass);
    }
    setErrorMessage(null);
    loginAsUser(userId);
  };

  const adminUsers = allUsers.filter(u => u.role === 'admin');
  const professorUsers = allUsers.filter(u => u.role === 'professor');
  const studentUsers = allUsers.filter(u => u.role === 'aluno');

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8 relative overflow-hidden select-none">
      {/* Background radial glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-red-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-0 right-10 w-[600px] h-[400px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-4xl relative z-10 space-y-6">
        
        {/* Top Header & Branding */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs font-semibold text-slate-300 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            Portal Oficial de Acesso Restrito • BJJ Flow
          </div>

          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-red-600 via-rose-600 to-amber-500 flex items-center justify-center font-black text-white text-xl shadow-xl shadow-red-900/30 border border-white/20">
              BJJ
            </div>
            <div className="text-left">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {academySettings.nomeAcademia || 'BJJ Flow Academia'}
              </h1>
              <p className="text-xs text-slate-400">
                Gestão do Tatame • Mestre {academySettings.mestreResponsavel}
              </p>
            </div>
          </div>
        </div>

        {/* Auth Box Grid */}
        <div className="bg-slate-900/90 backdrop-blur-xl border border-slate-800 rounded-3xl shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          
          {/* Left Column: Direct Login Form */}
          <div className="lg:col-span-6 p-6 sm:p-8 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-800">
            <div>
              <div className="space-y-1 mb-6">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Lock className="w-4 h-4 text-red-500" />
                  Identificação do Usuário
                </h2>
                <p className="text-xs text-slate-400">
                  Acesse com suas credenciais registradas no dojo.
                </p>
              </div>

              {errorMessage && (
                <div className="mb-5 p-3.5 rounded-xl bg-rose-950/60 border border-rose-800/80 text-rose-200 text-xs flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    E-mail de Acesso
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="thiagomoraes.mail@gmail.com"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 text-white rounded-xl px-3.5 py-2.5 pl-10 text-xs transition-all outline-none"
                      required
                    />
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-semibold text-slate-300">
                      Senha
                    </label>
                    <span className="text-[10px] text-slate-500">
                      Padrão demo: <code className="text-slate-400">123</code> ou <code className="text-slate-400">Pindorama@2507</code>
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 text-white rounded-xl px-3.5 py-2.5 pl-10 pr-10 text-xs transition-all outline-none"
                    />
                    <Key className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-3 text-slate-500 hover:text-slate-300"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-xs py-3 px-4 rounded-xl shadow-lg shadow-red-900/30 transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
                >
                  <span>Entrar no Sistema</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            </div>

            {/* Security Notice */}
            <div className="pt-6 mt-6 border-t border-slate-800/80 flex items-center gap-2.5 text-[11px] text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>Sessão protegida por criptografia e controle de níveis IBJJF.</span>
            </div>
          </div>

          {/* Right Column: Quick Profile Access */}
          <div className="lg:col-span-6 p-6 sm:p-8 bg-slate-950/60 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Acesso Rápido por Perfil
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Escolha um usuário cadastrado para teste ou demonstração:
                  </p>
                </div>
              </div>

              {/* Tabs for Roles */}
              <div className="flex p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setActiveTab('admin')}
                  className={`flex-1 py-1.5 px-2 rounded-lg font-bold transition-all text-center ${
                    activeTab === 'admin'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Mestre / Admin ({adminUsers.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('professor')}
                  className={`flex-1 py-1.5 px-2 rounded-lg font-bold transition-all text-center ${
                    activeTab === 'professor'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Professores ({professorUsers.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('aluno')}
                  className={`flex-1 py-1.5 px-2 rounded-lg font-bold transition-all text-center ${
                    activeTab === 'aluno'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Alunos ({studentUsers.length})
                </button>
              </div>

              {/* Tab Content Users */}
              <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1">
                {activeTab === 'admin' && (
                  adminUsers.map(user => (
                    <button
                      key={user.id}
                      type="button"
                      onClick={() => handleQuickLogin(user.id, user.email, user.password)}
                      className="w-full text-left p-3 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-red-500/50 transition-all group flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-red-950/80 border border-red-700/60 text-red-300 font-black text-xs flex items-center justify-center shrink-0">
                          {user.isMasterAdmin ? 'MST' : 'ADM'}
                        </div>
                        <div className="min-w-0">
                          <p className="font-bold text-xs text-white truncate group-hover:text-red-400 transition-colors">
                            {user.nome}
                          </p>
                          <p className="text-[11px] text-slate-400 truncate">{user.email}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {user.faixa && (
                          <BeltBadge faixa={user.faixa} graus={user.graus || 0} size="sm" />
                        )}
                        <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-red-400 transition-colors" />
                      </div>
                    </button>
                  ))
                )}

                {activeTab === 'professor' && (
                  professorUsers.length === 0 ? (
                    <p className="text-xs text-slate-500 italic p-4 text-center">
                      Nenhum professor cadastrado ainda.
                    </p>
                  ) : (
                    professorUsers.map(user => (
                      <button
                        key={user.id}
                        type="button"
                        onClick={() => handleQuickLogin(user.id, user.email, user.password || '123')}
                        className="w-full text-left p-3 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-blue-500/50 transition-all group flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-9 h-9 rounded-xl bg-blue-950/80 border border-blue-700/60 text-blue-300 font-black text-xs flex items-center justify-center shrink-0">
                            PROF
                          </div>
                          <div className="min-w-0">
                            <p className="font-bold text-xs text-white truncate group-hover:text-blue-400 transition-colors">
                              {user.nome}
                            </p>
                            <p className="text-[11px] text-slate-400 truncate">{user.email}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {user.faixa && (
                            <BeltBadge faixa={user.faixa} graus={user.graus || 0} size="sm" />
                          )}
                          <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-blue-400 transition-colors" />
                        </div>
                      </button>
                    ))
                  )
                )}

                {activeTab === 'aluno' && (
                  studentUsers.length === 0 ? (
                    <p className="text-xs text-slate-500 italic p-4 text-center">
                      Nenhum aluno cadastrado ainda.
                    </p>
                  ) : (
                    studentUsers.map(user => (
                      <button
                        key={user.id}
                        type="button"
                        onClick={() => handleQuickLogin(user.id, user.email, user.password || '123')}
                        className="w-full text-left p-3 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-emerald-500/50 transition-all group flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-9 h-9 rounded-xl bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 font-black text-xs flex items-center justify-center shrink-0">
                            AL
                          </div>
                          <div className="min-w-0">
                            <p className="font-bold text-xs text-white truncate group-hover:text-emerald-400 transition-colors">
                              {user.nome}
                            </p>
                            <p className="text-[11px] text-slate-400 truncate capitalize">
                              {user.faixa ? `Faixa ${user.faixa}` : user.email}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {user.faixa && (
                            <BeltBadge faixa={user.faixa} graus={user.graus || 0} size="sm" />
                          )}
                          <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-emerald-400 transition-colors" />
                        </div>
                      </button>
                    ))
                  )
                )}
              </div>
            </div>

            {/* Quick helper tip */}
            <div className="p-3 bg-slate-900/90 rounded-2xl border border-slate-800 text-[11px] text-slate-400 space-y-1 mt-4">
              <span className="font-bold text-slate-300 block">Dica para Administrador:</span>
              <p>
                Para gerenciar turmas, professores e finanças completas, selecione o perfil <strong>Thiago Lopes de Moraes Silva</strong> ou <strong>Carlos Mikalkenas</strong>.
              </p>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="text-center text-xs text-slate-500 space-y-1">
          <p>© {new Date().getFullYear()} BJJ Flow • Sistema de Gestão de Academia e Tatame de Jiu-Jitsu</p>
          <p className="text-[11px] text-slate-600">
            Normas de graduação e tempo mínimo em conformidade com as diretrizes da IBJJF / CBJJ.
          </p>
        </div>
      </div>
    </div>
  );
};
